import { initialEmployees, admins } from "./data.js";

const STORAGE_KEY = "employees";

// ================= EMPLOYEES =================
function getEmployees(){

    let employees = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");

    if(!employees || employees.length === 0){
        localStorage.setItem(STORAGE_KEY, JSON.stringify(initialEmployees));
        employees = initialEmployees;
    }

    return employees;
}

function saveEmployees(employees){
    localStorage.setItem(STORAGE_KEY, JSON.stringify(employees));
}

// ================= ADMINS =================
function getAdmins(){
    return admins;
}

function addAdmin(admin){
    admins.push(admin);
}

// ================= EXPORT =================
export default {
    getEmployees,
    saveEmployees,
    getAdmins,
    addAdmin
};
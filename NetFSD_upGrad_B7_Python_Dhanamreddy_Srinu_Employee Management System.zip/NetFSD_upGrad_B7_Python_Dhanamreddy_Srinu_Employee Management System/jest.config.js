export default {
  testEnvironment: "node"
};
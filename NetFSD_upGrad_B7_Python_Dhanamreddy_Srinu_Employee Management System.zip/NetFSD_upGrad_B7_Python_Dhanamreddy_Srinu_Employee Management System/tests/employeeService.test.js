import employeeService from "../js/employeeService.js";

// ✅ Mock localStorage
global.localStorage = {
    data: {},
    setItem(key, value) {
        this.data[key] = value;
    },
    getItem(key) {
        return this.data[key];
    }
};

describe("Employee Service Tests", () => {

    test("Add employee", () => {
        const emp = {
            firstName: "Test",
            lastName: "User",
            email: "test@mail.com",
            department: "Engineering",
            designation: "Dev",
            salary: 50000,
            joinDate: "2024-01-01",
            status: "Active"
        };

        employeeService.addEmployee(emp);

const list = employeeService.getEmployees();

expect(list.length).toBeGreaterThan(0);
    });

    test("Get employees", () => {
        const list = employeeService.getEmployees();
        expect(Array.isArray(list)).toBe(true);
    });

    test("Update employee", () => {
        const employees = employeeService.getEmployees();
        const emp = employees[0];

        emp.firstName = "Updated";

        employeeService.updateEmployee(emp);

        const updated = employeeService.getEmployees()[0];
        expect(updated.firstName).toBe("Updated");
    });

    test("Delete employee", () => {
        const employees = employeeService.getEmployees();
        const id = employees[0].id;

        employeeService.deleteEmployee(id);

        const newList = employeeService.getEmployees();
        expect(newList.find(e => e.id === id)).toBeUndefined();
    });

});
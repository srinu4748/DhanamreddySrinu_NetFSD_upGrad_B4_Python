// ================= IMPORTS =================
import employeeService from "./employeeService.js";
import dashboardService from "./dashboardService.js";
import uiService from "./uiService.js";
import validationService from "./validationService.js";
import authService from "./authService.js";

// ================= GLOBAL =================
let allEmployees = [];
let currentStatus = "All";
let editId = null;
let deleteId = null; // ✅ FIX

// ================= LOGIN / SIGNUP =================
$(document).ready(function () {

    // NAVIGATION
    $("#goToSignup").click(() => {
        $("#loginSection").hide();
        $("#signupSection").show();
    });

    $("#goToLogin").click(() => {
        $("#signupSection").hide();
        $("#loginSection").show();
    });

    // SIGNUP
    $("#signupBtn").click(function () {

        const data = {
            username: $("#signupUsername").val().trim(),
            password: $("#signupPassword").val().trim(),
            confirmPassword: $("#signupConfirmPassword").val().trim()
        };

        const errors = validationService.validateAuthForm(data, "signup");

        $(".text-danger").text("");

        if (Object.keys(errors).length > 0) {
            $("#usernameError").text(errors.username || "");
            $("#passwordError").text(errors.password || "");
            $("#confirmPasswordError").text(errors.confirmPassword || "");
            return;
        }

        const result = authService.signup(data.username, data.password);

        if (!result.success) {
            $("#usernameError").text(result.message);
            return;
        }

        uiService.showToast("Signup successful!");

        setTimeout(() => {
            $("#signupSection").hide();
            $("#loginSection").show();
        }, 1000);
    });

    // LOGIN
    $("#loginBtn").click(function () {

        const data = {
            username: $("#loginUsername").val().trim(),
            password: $("#loginPassword").val().trim()
        };

        if (!data.username || !data.password) {
            $("#loginError").text("All fields required");
            return;
        }

        const result = authService.login(data.username, data.password);

        if (!result.success) {
            $("#loginError").text("Invalid credentials");
            return;
        }

        uiService.showToast("Login successful!");

        setTimeout(() => {
            $("#loginSection").hide();
            $("#signupSection").hide();
            $("#mainApp").show();

            document.getElementById("currentUserBtn").textContent =
                authService.getCurrentUser();

            init();
        }, 1000);
    });

    // LOGOUT
    $("#logoutBtn").click(function () {
        $("#mainApp").hide();
        $("#loginSection").show();
    });

    // ✅ CONFIRM DELETE BUTTON (FIXED)
    $("#confirmDeleteBtn").click(function(){

        if(deleteId){
            employeeService.deleteEmployee(deleteId);
            loadAllData();
            deleteId = null;
        }

        const modal = bootstrap.Modal.getInstance(
            document.getElementById("deleteModal")
        );

        if(modal){
            modal.hide();
        }
    });

});

// ================= INIT =================
function init() {
    setupNavigation();
    setupFilters();
    setupAddButtons();
    loadAllData();

    // Default active
    dashboardTab.className = "btn btn-light";
    employeesTab.className = "btn btn-outline-light";
}

// ================= LOAD =================
function loadAllData() {

    allEmployees = employeeService.getEmployees();

    // Render table
    uiService.renderEmployeeTable(allEmployees);

    // Dashboard
    const summary = dashboardService.getSummary();
    uiService.renderDashboard(summary);
    uiService.renderDepartmentBreakdown(
        dashboardService.getDepartmentBreakdown()
    );
    uiService.renderRecentEmployees(
        dashboardService.getRecentEmployees()
    );

    updateCount(allEmployees);

    // ✅ VERY IMPORTANT FIX
    setupAddButtons();   // <-- this line fixes your problem

    // Events
    attachEvents();
}
// ================= NAVIGATION =================
function setupNavigation() {

  dashboardTab.onclick = () => {

    dashboardSection.style.display = "block";
    employeesSection.style.display = "none";

    dashboardTab.className = "btn btn-light";
    employeesTab.className = "btn btn-outline-light";
  };

  employeesTab.onclick = () => {

    dashboardSection.style.display = "none";
    employeesSection.style.display = "block";

    employeesTab.className = "btn btn-light";
    dashboardTab.className = "btn btn-outline-light";
  };
}

// ================= ADD =================
function setupAddButtons() {

    // Navbar Add button
    $("#addEmployeeBtn").off("click").on("click", openAddModal);

    // Employee section Add button
    $("#addEmployeeBtn2").off("click").on("click", openAddModal);

    $("#addEmployeeBtn3").off("click").on("click", openAddModal);

    // Save button
    $("#saveEmployeeBtn").off("click").on("click", saveEmployee);
}

function clearForm() {
    document.querySelectorAll("#employeeModal input").forEach(i => i.value = "");
}

function openAddModal() {
    editId = null;
    clearForm();

    bootstrap.Modal.getOrCreateInstance(
        document.getElementById("employeeModal")
    ).show();
}

// ================= SAVE =================
function saveEmployee() {

    const fName = firstName.value.trim();
    const lName = lastName.value.trim();
    const mail = email.value.trim();
    const ph = phone.value.trim();
    const dept = department.value;
    const desig = designation.value.trim();
    const sal = salary.value;
    const date = joinDate.value;
    const stat = status.value;

    if (
        fName === "" ||
        lName === "" ||
        mail === "" ||
        ph === "" ||
        desig === "" ||
        sal === "" ||
        date === ""
    ) {
        alert("Please fill all fields");
        return;
    }

    const emp = {
        id: editId,
        firstName: fName,
        lastName: lName,
        email: mail,
        phone: ph,
        department: dept,
        designation: desig,
        salary: Number(sal),
        joinDate: date,
        status: stat
    };

    if (editId) {
        employeeService.updateEmployee(emp);
    } else {
        employeeService.addEmployee(emp);
    }

    bootstrap.Modal.getInstance(
        document.getElementById("employeeModal")
    ).hide();

    clearForm();
    loadAllData();
}

// ================= FILTER =================
function setupFilters() {

    searchInput.oninput = applyFilters;
    departmentFilter.onchange = applyFilters;

    document.querySelectorAll(".statusBtn").forEach(btn => {
        btn.onclick = () => {
            document.querySelectorAll(".statusBtn")
                .forEach(b => b.classList.remove("active"));

            btn.classList.add("active");

            currentStatus = btn.dataset.status;

            applyFilters();
        };
    });
}

function applyFilters() {

    let filtered = [...allEmployees];

    if (searchInput.value) {
        const text = searchInput.value.toLowerCase();

        filtered = filtered.filter(e =>
            `${e.firstName} ${e.lastName}`.toLowerCase().includes(text) ||
            e.email.toLowerCase().includes(text)
        );
    }

    if (departmentFilter.value !== "All") {
        filtered = filtered.filter(e => e.department === departmentFilter.value);
    }

    if (currentStatus !== "All") {
        filtered = filtered.filter(e => e.status === currentStatus);
    }

    uiService.renderEmployeeTable(filtered);
    updateCount(filtered);
}

// ================= COUNT =================
function updateCount(list) {
    employeeCountText.textContent =
        `Showing ${list.length} of ${allEmployees.length} employees`;
}

// ================= EVENTS =================
function attachEvents(){

const tableBody = document.getElementById("employeeTableBody");

tableBody.addEventListener("click", function(e){

const btn = e.target.closest("button");
if(!btn) return;

const id = Number(btn.dataset.id);
if(!id) return;

const emp = allEmployees.find(e => e.id === id);
if(!emp) return;

// ✅ DELETE FIXED
if(btn.classList.contains("deleteBtn")){

    deleteId = id;

    document.getElementById("deleteEmpName").textContent =
        emp.firstName + " " + emp.lastName;

    bootstrap.Modal.getOrCreateInstance(
        document.getElementById("deleteModal")
    ).show();
}

// VIEW
if(btn.classList.contains("viewBtn")){
    viewAvatar.innerText = emp.firstName[0] + emp.lastName[0];
    viewName.innerText = emp.firstName + " " + emp.lastName;
    viewDept.innerText = emp.department;
    viewEmail.innerText = emp.email;
    viewPhone.innerText = emp.phone || "-";
    viewDesignation.innerText = emp.designation;
    viewSalary.innerText = "₹" + emp.salary.toLocaleString();
    viewJoin.innerText = emp.joinDate;

    viewStatus.innerHTML = emp.status==="Active"
    ? `<span class="badge bg-success">Active</span>`
    : `<span class="badge bg-danger">Inactive</span>`;

    bootstrap.Modal.getOrCreateInstance(
        document.getElementById("viewModal")
    ).show();
}

// EDIT
if(btn.classList.contains("editBtn")){

    editId = emp.id;

    document.getElementById("firstName").value = emp.firstName;
    document.getElementById("lastName").value = emp.lastName;
    document.getElementById("email").value = emp.email;
    document.getElementById("phone").value = emp.phone;
    document.getElementById("department").value = emp.department;
    document.getElementById("designation").value = emp.designation;
    document.getElementById("salary").value = emp.salary;
    document.getElementById("joinDate").value = emp.joinDate;
    document.getElementById("status").value = emp.status;

    bootstrap.Modal.getOrCreateInstance(
        document.getElementById("employeeModal")
    ).show();
}

});
}
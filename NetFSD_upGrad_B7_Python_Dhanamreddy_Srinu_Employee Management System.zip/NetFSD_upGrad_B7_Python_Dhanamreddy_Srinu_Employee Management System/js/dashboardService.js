import storageService from "./storageService.js";

// =======================
// SUMMARY
// =======================

function getSummary(){

    const employees = storageService.getEmployees();

    return {
        totalEmployees: employees.length,
        activeEmployees: employees.filter(e => e.status === "Active").length,
        inactiveEmployees: employees.filter(e => e.status === "Inactive").length,
        departments: [...new Set(employees.map(e => e.department))].length
    };

}

// =======================
// DEPARTMENT BREAKDOWN
// =======================

function getDepartmentBreakdown(){

    const employees = storageService.getEmployees();

    const result = {};

    employees.forEach(emp => {

        if(!result[emp.department]){
            result[emp.department] = 0;
        }

        result[emp.department]++;

    });

    return result;

}

// =======================
// RECENT EMPLOYEES
// =======================

function getRecentEmployees(n = 5){

    const employees = storageService.getEmployees();

    return [...employees].slice(-n).reverse();

}

// =======================
// EXPORT
// =======================

export default {
    getSummary,
    getDepartmentBreakdown,
    getRecentEmployees
};
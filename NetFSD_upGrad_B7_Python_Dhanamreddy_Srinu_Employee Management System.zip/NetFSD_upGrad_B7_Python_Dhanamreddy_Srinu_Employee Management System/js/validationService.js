// =======================================
// Validation Service (FINAL MERGED)
// =======================================

const validationService = (function () {

    // ================= EMAIL =================
    function isValidEmail(email) {
        const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return pattern.test(email);
    }

    // ================= PHONE =================
    function isValidPhone(phone) {
        const pattern = /^[0-9]{10}$/;
        return pattern.test(phone);
    }

    // ================= SALARY =================
    function isValidSalary(salary) {
        return !isNaN(salary) && Number(salary) > 0;
    }

    // ================= AUTH VALIDATION (USED IN app.js) =================
    function validateAuthForm(data, type) {

        let errors = {};

        if (!data.username) {
            errors.username = "Username required";
        }

        if (!data.password) {
            errors.password = "Password required";
        } 
        else if (data.password.length < 6) {
            errors.password = "Minimum 6 characters";
        }

        if (type === "signup") {
            if (!data.confirmPassword) {
                errors.confirmPassword = "Confirm password required";
            } 
            else if (data.password !== data.confirmPassword) {
                errors.confirmPassword = "Passwords do not match";
            }
        }

        return errors;
    }

    // ================= EMPLOYEE VALIDATION =================
    function validateEmployee(employeeData) {

        const errors = {};

        if (!employeeData.firstName) {
            errors.firstName = "First name is required";
        }

        if (!employeeData.lastName) {
            errors.lastName = "Last name is required";
        }

        if (!employeeData.email) {
            errors.email = "Email is required";
        }
        else if (!isValidEmail(employeeData.email)) {
            errors.email = "Invalid email format";
        }

        if (!employeeData.phone) {
            errors.phone = "Phone number is required";
        }
        else if (!isValidPhone(employeeData.phone)) {
            errors.phone = "Phone must be 10 digits";
        }

        if (!employeeData.department) {
            errors.department = "Department is required";
        }

        if (!employeeData.designation) {
            errors.designation = "Designation is required";
        }

        if (!employeeData.salary) {
            errors.salary = "Salary is required";
        }
        else if (!isValidSalary(employeeData.salary)) {
            errors.salary = "Salary must be positive";
        }

        if (!employeeData.joinDate) {
            errors.joinDate = "Join date required";
        }

        if (!employeeData.status) {
            errors.status = "Status required";
        }

        return errors;
    }

    // ================= DUPLICATE EMAIL =================
    function isDuplicateEmail(email, employees, currentId = null) {

        return employees.some(emp => {

            if (currentId && emp.id === currentId) return false;

            return emp.email.toLowerCase() === email.toLowerCase();

        });
    }

    // ================= EXPORT =================
    return {
        validateAuthForm,
        validateEmployee,
        isValidEmail,
        isValidPhone,
        isValidSalary,
        isDuplicateEmail
    };

})();

export default validationService;
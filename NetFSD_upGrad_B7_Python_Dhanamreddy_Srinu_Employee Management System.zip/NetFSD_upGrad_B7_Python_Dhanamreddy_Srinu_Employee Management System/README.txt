Name: Srinu
Batch: 07
Project: Employee Management System

How to run project:
1. Open index.html in browser

How to run tests:
1. Open terminal
2. Run: npm install
3. Run: npm test
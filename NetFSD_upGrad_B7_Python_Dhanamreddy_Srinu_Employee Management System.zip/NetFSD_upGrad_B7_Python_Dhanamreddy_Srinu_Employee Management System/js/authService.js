// =======================================
// Authentication Service (FINAL MERGED)
// =======================================

const authService = (function () {

    const ADMIN_KEY = "adminUser";
    const SESSION_KEY = "loggedInUser";

    // ================= SIGNUP =================
    function signup(username, password) {

        const existingAdmin = JSON.parse(localStorage.getItem(ADMIN_KEY) || "null");

        if (existingAdmin && existingAdmin.username === username) {
            return {
                success: false,
                message: "Username already exists"
            };
        }

        const admin = {
            username: username,
            password: password
        };

        localStorage.setItem(ADMIN_KEY, JSON.stringify(admin));

        return {
            success: true,
            message: "Signup successful"
        };
    }

    // ================= LOGIN =================
    function login(username, password) {

        const storedAdmin = JSON.parse(localStorage.getItem(ADMIN_KEY) || "null");

        if (!storedAdmin) {
            return {
                success: false,
                message: "Admin not registered"
            };
        }

        if (
            storedAdmin.username === username &&
            storedAdmin.password === password
        ) {

            localStorage.setItem(SESSION_KEY, username);

            return {
                success: true,
                message: "Login successful"
            };
        }

        return {
            success: false,
            message: "Invalid credentials"
        };
    }

    // ================= LOGOUT =================
    function logout() {
        localStorage.removeItem(SESSION_KEY);
    }

    // ================= SESSION CHECK =================
    function isLoggedIn() {
        return localStorage.getItem(SESSION_KEY) !== null;
    }

    // ================= CURRENT USER =================
    function getCurrentUser() {
        return localStorage.getItem(SESSION_KEY);
    }

    return {
        signup,
        login,
        logout,
        isLoggedIn,
        getCurrentUser
    };

})();

export default authService;
export const initialEmployees = [
{ id:1, firstName:"Rahul", lastName:"Kumar", email:"rahul.kumar@techcore.com", phone:"9123456780", department:"Engineering", designation:"Software Engineer", salary:820000, joinDate:"2021-04-12", status:"Active"},
{ id:2, firstName:"Sneha", lastName:"Patel", email:"sneha.patel@techcore.com", phone:"9123456781", department:"Marketing", designation:"Marketing Executive", salary:610000, joinDate:"2020-08-05", status:"Active"},
{ id:3, firstName:"Kiran", lastName:"Reddy", email:"kiran.reddy@techcore.com", phone:"9123456782", department:"HR", designation:"HR Executive", salary:540000, joinDate:"2019-12-10", status:"Active"},
{ id:4, firstName:"Aakash", lastName:"Mehta", email:"aakash.mehta@techcore.com", phone:"9123456783", department:"Finance", designation:"Financial Analyst", salary:730000, joinDate:"2022-02-15", status:"Active"},
{ id:5, firstName:"Pooja", lastName:"Nair", email:"pooja.nair@techcore.com", phone:"9123456784", department:"Operations", designation:"Operations Manager", salary:960000, joinDate:"2018-07-20", status:"Active"},
{ id:6, firstName:"Vishal", lastName:"Singh", email:"vishal.singh@techcore.com", phone:"9123456785", department:"Engineering", designation:"Senior Developer", salary:1150000, joinDate:"2017-10-08", status:"Active"},
{ id:7, firstName:"Anjali", lastName:"Gupta", email:"anjali.gupta@techcore.com", phone:"9123456786", department:"Marketing", designation:"Content Strategist", salary:590000, joinDate:"2023-03-01", status:"Inactive"},
{ id:8, firstName:"Rohit", lastName:"Das", email:"rohit.das@techcore.com", phone:"9123456787", department:"Finance", designation:"Accounts Manager", salary:810000, joinDate:"2020-05-10", status:"Active"},
{ id:9, firstName:"Megha", lastName:"Iyer", email:"megha.iyer@techcore.com", phone:"9123456788", department:"Engineering", designation:"DevOps Engineer", salary:910000, joinDate:"2021-09-25", status:"Active"},
{ id:10, firstName:"Sandeep", lastName:"Yadav", email:"sandeep.yadav@techcore.com", phone:"9123456789", department:"Operations", designation:"Supply Chain Analyst", salary:680000, joinDate:"2022-04-18", status:"Active"},
{ id:11, firstName:"Lakshmi", lastName:"Menon", email:"lakshmi.menon@techcore.com", phone:"9123456790", department:"Marketing", designation:"Brand Manager", salary:870000, joinDate:"2021-11-15", status:"Active"},
{ id:12, firstName:"Ramesh", lastName:"Naidu", email:"ramesh.naidu@techcore.com", phone:"9123456791", department:"Finance", designation:"Tax Consultant", salary:760000, joinDate:"2019-06-22", status:"Inactive"},
{ id:13, firstName:"Divya", lastName:"Sharma", email:"divya.sharma@techcore.com", phone:"9123456792", department:"Engineering", designation:"QA Engineer", salary:610000, joinDate:"2020-12-05", status:"Active"},
{ id:14, firstName:"Manoj", lastName:"Verma", email:"manoj.verma@techcore.com", phone:"9123456793", department:"HR", designation:"HR Manager", salary:720000, joinDate:"2018-04-14", status:"Active"},
{ id:15, firstName:"Keerthi", lastName:"Rao", email:"keerthi.rao@techcore.com", phone:"9123456794", department:"Operations", designation:"Operations Executive", salary:520000, joinDate:"2023-01-20", status:"Inactive"}
];

export const admins = [
    { username: "admin", password: "admin123" }
];
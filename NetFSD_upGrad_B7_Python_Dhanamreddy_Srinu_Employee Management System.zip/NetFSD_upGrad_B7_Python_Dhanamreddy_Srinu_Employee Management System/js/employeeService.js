import storageService from "./storageService.js";

// ================= GET =================
function getEmployees(){
    return storageService.getEmployees();
}

// ================= ADD =================
function addEmployee(emp){

    const list = getEmployees();

    emp.id = list.length ? list[list.length - 1].id + 1 : 1;

    list.push(emp);

    storageService.saveEmployees(list);
}

// ================= DELETE =================
function deleteEmployee(id){

    let list = getEmployees();

    list = list.filter(e => e.id !== id);

    storageService.saveEmployees(list);
}

// ================= UPDATE =================
function updateEmployee(emp){

    let list = getEmployees();

    list = list.map(e => e.id === emp.id ? emp : e);

    storageService.saveEmployees(list);
}

// ================= SEARCH =================
function searchEmployees(query){

    const employees = getEmployees();

    return employees.filter(emp =>

        (emp.firstName + " " + emp.lastName)
        .toLowerCase()
        .includes(query.toLowerCase())

        ||

        emp.email.toLowerCase()
        .includes(query.toLowerCase())

    );
}

// ================= FILTER DEPT =================
function filterByDepartment(dept){

    const employees = getEmployees();

    if(dept === "All") return employees;

    return employees.filter(e => e.department === dept);
}

// ================= FILTER STATUS =================
function filterByStatus(status){

    const employees = getEmployees();

    if(status === "All") return employees;

    return employees.filter(e => e.status === status);
}

// ================= EXPORT =================
export default {
    getEmployees,
    addEmployee,
    deleteEmployee,
    updateEmployee,
    searchEmployees,
    filterByDepartment,
    filterByStatus
};
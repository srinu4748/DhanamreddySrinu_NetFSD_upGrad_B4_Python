// ===============================
// UI SERVICE (FINAL MERGED)
// ===============================

// ================= TOAST =================
function showToast(message){

    document.getElementById("toastText").innerText = message;

    const toast = new bootstrap.Toast(
        document.getElementById("toastMsg")
    );

    toast.show();
}

// ================= AVATAR =================
function avatar(first, last){
    return `<div class="avatar">${first[0]}${last[0]}</div>`;
}

// ================= DEPARTMENT BADGE =================
function departmentBadge(dept){

    const colors={
        Engineering:"primary",
        Marketing:"warning",
        HR:"info",
        Finance:"success",
        Operations:"secondary"
    };

    return `<span class="badge bg-${colors[dept]||"dark"}">${dept}</span>`;
}

// ================= STATUS BADGE =================
function statusBadge(status){

    if(status==="Active"){
        return `<span class="badge bg-success">Active</span>`;
    }

    return `<span class="badge bg-danger">Inactive</span>`;
}

// ================= DASHBOARD =================
function renderDashboard(summary){

    document.getElementById("totalEmployees").textContent = summary.totalEmployees;
    document.getElementById("activeEmployees").textContent = summary.activeEmployees;
    document.getElementById("inactiveEmployees").textContent = summary.inactiveEmployees;
    document.getElementById("totalDepartments").textContent = summary.departments;

}

// ================= DEPARTMENT BREAKDOWN =================
function renderDepartmentBreakdown(data){

const container = document.getElementById("departmentBreakdown");

container.innerHTML = "";

// ✅ ADD HEADINGS
container.innerHTML = `
<div class="d-flex fw-bold mb-2">
  <div style="width:120px">Department</div>
  <div style="width:60px">Count</div>
  <div style="flex:1">Distribution</div>
  <div style="width:40px">%</div>
</div>
`;

const total = Object.values(data).reduce((a,b)=>a+b,0);

Object.entries(data).forEach(([dept,count])=>{

const percent = Math.round((count/total)*100);

container.innerHTML += `

<div class="department-item">

<div style="width:120px">
${departmentBadge(dept)}
</div>

<div style="width:60px">
${count}
</div>

<div style="flex:1" class="mx-2">
<div class="progress">
<div class="progress-bar" style="width:${percent}%"></div>
</div>
</div>

<div style="width:40px">
${percent}%
</div>

</div>

`;

});

}

// ================= RECENT EMPLOYEES =================
function renderRecentEmployees(list){

    const container = document.getElementById("recentEmployees");

    container.innerHTML = "";

    list.forEach(emp=>{

        container.innerHTML += `

        <div class="recent-item">

        <div class="d-flex align-items-center gap-2">

        ${avatar(emp.firstName,emp.lastName)}

        <div>

        <strong>${emp.firstName} ${emp.lastName}</strong><br>

        <small class="text-muted">
        ${emp.designation}
        </small>

        </div>

        </div>

        <div>
        ${departmentBadge(emp.department)}
        ${statusBadge(emp.status)}
        </div>

        </div>
        `;
    });

}

// ================= EMPLOYEE TABLE =================
function renderEmployeeTable(employees){

    const tbody = document.getElementById("employeeTableBody");

    tbody.innerHTML = "";

    employees.forEach(emp=>{

        tbody.innerHTML += `

        <tr>

        <td>${emp.id}</td>

        <td>${avatar(emp.firstName,emp.lastName)}</td>

        <td>${emp.firstName} ${emp.lastName}</td>

        <td>${emp.email}</td>

        <td>${departmentBadge(emp.department)}</td>

        <td>${emp.designation}</td>

        <td>₹${emp.salary.toLocaleString()}</td>

       <td class="nowrap">${emp.joinDate}</td>

        <td>${statusBadge(emp.status)}</td>

        <td class="nowrap">

        <button class="btn btn-sm btn-outline-primary viewBtn" data-id="${emp.id}">
        👁
        </button>

        <button class="btn btn-sm btn-outline-warning editBtn" data-id="${emp.id}">
        ✏
        </button>

        <button class="btn btn-sm btn-outline-danger deleteBtn" data-id="${emp.id}">
        🗑
        </button>

        </td>

        </tr>
        `;
    });

}

// ================= EXPORT =================
export default {
    showToast,
    renderDashboard,
    renderDepartmentBreakdown,
    renderRecentEmployees,
    renderEmployeeTable
};
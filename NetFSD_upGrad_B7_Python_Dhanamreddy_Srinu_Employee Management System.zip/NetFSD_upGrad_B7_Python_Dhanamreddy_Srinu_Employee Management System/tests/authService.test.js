import authService from "../js/authService.js";

// ✅ Mock localStorage
global.localStorage = {
    data: {},

    setItem(key, value) {
        this.data[key] = value;
    },

    getItem(key) {
        return this.data[key] || null; // ✅ FIX
    },

    removeItem(key) {
        delete this.data[key];
    }
};
describe("Auth Service Tests", () => {

    test("Signup should create new user", () => {
        const result = authService.signup("testuser", "123456");
        expect(result.success).toBe(true);
    });

    test("Signup should fail for duplicate user", () => {
        authService.signup("duplicate", "123456");
        const result = authService.signup("duplicate", "123456");
        expect(result.success).toBe(false);
    });

    test("Login should succeed with correct credentials", () => {
        authService.signup("loginuser", "123456");
        const result = authService.login("loginuser", "123456");
        expect(result.success).toBe(true);
    });

    test("Login should fail with wrong credentials", () => {
        const result = authService.login("wrong", "123");
        expect(result.success).toBe(false);
    });

});
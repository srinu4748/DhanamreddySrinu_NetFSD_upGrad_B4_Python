import dashboardService from "../js/dashboardService.js";
import employeeService from "../js/employeeService.js";

// ✅ Mock localStorage
global.localStorage = {
    data: {},
    setItem(key, value) {
        this.data[key] = value;
    },
    getItem(key) {
        return this.data[key];
    }
};

describe("Dashboard Service Tests", () => {

    beforeAll(() => {
        // Add sample employees
        employeeService.addEmployee({
            firstName: "A",
            lastName: "B",
            email: "a@mail.com",
            department: "Engineering",
            designation: "Dev",
            salary: 50000,
            joinDate: "2024-01-01",
            status: "Active"
        });

        employeeService.addEmployee({
            firstName: "C",
            lastName: "D",
            email: "c@mail.com",
            department: "HR",
            designation: "HR",
            salary: 40000,
            joinDate: "2024-01-02",
            status: "Inactive"
        });
    });

    test("Get summary", () => {
        const summary = dashboardService.getSummary();

        expect(summary.totalEmployees).toBeGreaterThan(0);
        expect(summary.activeEmployees).toBeDefined();
        expect(summary.inactiveEmployees).toBeDefined();
    });

    test("Department breakdown", () => {
        const data = dashboardService.getDepartmentBreakdown();

        expect(typeof data).toBe("object");
    });

    test("Recent employees", () => {
        const list = dashboardService.getRecentEmployees();

        expect(Array.isArray(list)).toBe(true);
    });

});